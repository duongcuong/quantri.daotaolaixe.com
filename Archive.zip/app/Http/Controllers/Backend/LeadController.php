<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Lead;
use App\Models\User;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LeadController extends Controller
{
    public function index()
    {
        return view('backend.leads.index');
    }

    public function create()
    {
        return view('backend.leads.modals.create');
    }

    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'user_id' => 'nullable|exists:users,id',
            'source' => 'nullable|string|max:255',
            'interest_level' => 'required|in:low,medium,high',
            'status' => 'nullable|string|max:50', // Cập nhật validation cho trường status
            'assigned_to' => 'required|exists:admins,id',
            'name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string|max:255',
            'description' => 'nullable|string',
            'dob' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        Lead::create($request->all());

        return response()->json(['success' => 'Thêm thành công.']);
    }

    public function show(Lead $lead)
    {
        return view('backend.leads.show', compact('lead'));
    }

    public function edit(Lead $lead)
    {
        return view('backend.leads.modals.edit', compact('lead'));
    }

    public function update(Request $request, Lead $lead)
    {

        $validator = Validator::make($request->all(), [
            'user_id' => 'nullable|exists:users,id',
            'source' => 'nullable|string|max:255',
            'interest_level' => 'required|in:low,medium,high',
            'status' => 'nullable|string|max:50',
            'assigned_to' => 'required|exists:admins,id',
            'name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string|max:255',
            'description' => 'nullable|string',
            'dob' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $lead->update($request->all());

        return response()->json(['success' => 'Cập nhật thành công.']);

    }

    public function destroy(Lead $lead)
    {
        $lead->delete();
        return redirect()->route('leads.index')->with('success', 'Lead deleted successfully.');
    }

    public function data(Request $request)
    {
        $leads = Lead::with(['user', 'assignedTo'])->orderBy('id', 'desc')->paginate(LIMIT);

        if ($request->ajax()) {
            return view('backend.leads.partials.data', compact('leads'))->render();
        }

        return view('backend.leads.index', compact('leads'));
    }
}
